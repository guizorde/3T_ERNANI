import { acelerar } from "./lib/veiculo.js";

import { fs } from  "./lib/Modulo.cjs";

console.log(acelerar());
console.log(acelerar());
console.log(fs);