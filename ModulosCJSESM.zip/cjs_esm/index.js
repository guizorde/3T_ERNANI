import { carro } from "./lib/carro.js";

import { fs } from "./lib/modulo.cjs";

console.log(carro());

console.log(fs);
