const express = require("express");
const app = express(); // criado uma instancia de express

const PORT = 33333;
app.get("/", function (req, res) {
  res.send("Hello Página HOME");
});
app.get("/sobre", function (req, res) {
  res.send("<h1'>Página sobre</h1>");
});

app.listen(PORT, function () {
  console.log("Servidor rodando na porta: " + PORT);
});