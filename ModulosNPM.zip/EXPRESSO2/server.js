//criar o nosso servidor
const express = require("express");
const path = require("path");
const app = express();

const port = 3333;

//criar rotas
app.get("/", function (req, res) {

  res.send('Hello')
});

//usar servidor numa dada porta
app.listen(3333, function () {
  console.log("Rodando na porta" + port);
});
