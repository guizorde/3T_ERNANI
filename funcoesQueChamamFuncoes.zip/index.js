/** crie um array de objetos => pessoas
com os seguites atributos: nome/sobrenome
crie uma função que itere sobre o array
e retire nomes e sobrenomes
crie uma variável com o conteúdo:
     -> const emailBase = "@escola.pr.gov.br
a partir desses dados forme um @escola com nome.sobre+emailbase"
execute a função
*/
const pessoas = [
  { nome: "João", sobrenome: "Silva" },
  { nome: "Maria", sobrenome: "Souza" },
];
// criar emai base
const emailBase = "@escola.pr.gov.br";

//função de impressão
function gerarEmail() {
  if (pessoas.lenght == 0) {
    console.log("Nenhum aluno cadastrado");
  } else {
    for (pessoa of pessoas) {
      const nome = pessoa.nome;
      const sobrenome = pessoa.sobrenome;
      const email = `${nome}.${sobrenome}${emailBase}`;
      console.log(email);
    }
  }
}

//função de cadastro
function cadastrarAluno(nome, sobrenome) {
  pessoas.push({ nome: nome, sobrenome: sobrenome });
}
//cadastre 5 alunos
cadastrarAluno("Pedro", "Santos");
cadastrarAluno("Ana", "Silva");
cadastrarAluno("Carlos", "Pereira");
cadastrarAluno("Maria", "Oliveira");
cadastrarAluno("João", "Rodrigues");

gerarEmail();
