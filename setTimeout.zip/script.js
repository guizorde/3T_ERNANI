let n = 0;
const intervalo1 = setInterval(function() {
  console.clear();
  console.log('Contador: ' + n)
  n++;
  // setTimeout - espere e depois execute
}, 1000);
setTimeout(function() { // executa apenas uma vez
  clearInterval(intervalo1)
  window.alert('Redirecionando')
  location.href = "https://www.youtube.com/results?search_query="
}, 5000)